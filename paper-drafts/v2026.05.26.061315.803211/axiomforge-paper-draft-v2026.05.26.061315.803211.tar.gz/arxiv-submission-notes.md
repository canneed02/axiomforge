# arXiv Submission Notes

This package is arXiv-ready in structure but must not be submitted under a
human identity by automation.

- Authorship disclosure: `AxiomForge Autonomous System`
- Source TeX: `paper.tex`
- Bibliography: `references.bib`
- Release tag: `axiomforge-public-ledger-v2026.05.26.061309.663494`
- Public site: https://canneed02.github.io/axiomforge/
- Required human/bot-operator check: confirm arXiv policy and identity before
  any external submission.
